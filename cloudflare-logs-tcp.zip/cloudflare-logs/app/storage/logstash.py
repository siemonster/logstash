# -*- coding: utf-8 -*-
from .base import BaseStorageAdapter
from threading import Event
import logging
import logstash
__all__ = [
    "LogstashStorage"
]


class LogstashStorage(BaseStorageAdapter):
    def __init__(self, queue, stop_event:Event, host, port, logger=None, name=None):
        self._host = host
        self._port = port
        super().__init__(queue, stop_event=stop_event, logger=logger, name=name)

    def run(self):
        self._logger.debug("Starting")

        logstash_logger = logging.getLogger('python-logstash-logger')
        logstash_logger.setLevel(logging.INFO)
        logstash_logger.addHandler(logstash.TCPLogstashHandler(self._host, self._port, version=1))
        logstash_logger.propagate = False

        while self._is_running or self._queue.qsize() > 0:
            raw = self._queue.get()

            logstash_logger.info('', extra=raw)

            self._queue.task_done()
