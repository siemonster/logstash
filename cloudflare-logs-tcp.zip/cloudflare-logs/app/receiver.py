# -*- coding: utf-8 -*-
from queue import Queue
from threading import Thread, Event
import logging


class Receiver(Thread):
    def __init__(self, queue:Queue, stop_event:Event, adapter, adapter_args=None, logger=None, adapter_kwargs=None, num_workers:int=20):
        Thread.__init__(self, name="Receiver")
        self._adapter = adapter
        self._adapter_args = adapter_args or ()
        self._adapter_kwargs = adapter_kwargs or {}
        self._queue = queue
        self._stop_event = stop_event
        self._workers_num = num_workers
        self._workers = []
        self._logger = logger or logging

    def run(self):
        self._logger.info("Starting (%s workers)" % self._workers_num)
        for w in range(self._workers_num):
            inst = self._adapter(
                self._queue, self._stop_event, *self._adapter_args, **self._adapter_kwargs, logger=self._logger,
                name="StorageWorker-%s" % w
            )
            inst.start()
            self._workers.append(inst)
        for w in self._workers:
            w.join()

    def stop(self):
        for w in self._workers:
            self._logger.debug("Stopping %s" % w.name)
            w.stop()
