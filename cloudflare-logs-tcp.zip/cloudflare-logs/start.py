# -*- coding: utf-8 -*-
from app.watcher import Watcher
from app.environment import Environment
from app.storage import NullStorage, LogstashStorage
from app.monotonic import MonotonicGenerator
from app.receiver import Receiver
from app.producer import CloudFlareProducer
from queue import Queue
from threading import Event
import logging
import sys

LOG_LEVELS = {
    "CRITICAL": logging.CRITICAL,
    "ERROR": logging.ERROR,
    "WARNING": logging.WARN,
    "INFO": logging.INFO,
    "DEBUG": logging.DEBUG,
    "NOTSET": logging.NOTSET,
}

env_vars = {
    "CF_API_EMAIL": {
        "required": True,
        "description": "CloudFlare Account email",
    },
    "CF_API_KEY": {
        "required": True,
        "description": "CloudFlare Account API key",
    },
    "CF_ZONE_ID": {
        "required": True,
        "description": "CloudFlare Zone ID",
    },
    "CF_LOGS_START": {
        "required": True,
        "description": "The starting position of the logs. Must be no more than 7 days from now.",
        "default": "0",
        "type": float,
    },
    "LOGSTASH_HOST": {
        "required": True,
        "description": "Logstash host",
        "default": "logstash",
    },
    "LOGSTASH_PORT": {
        "required": True,
        "description": "Logstash port",
        "default": "5959",
        "type": int,
    },
    "LOG_LEVEL": {
        "required": True,
        "description": "Log level",
        "default": "INFO",
        "type": lambda x: LOG_LEVELS[x],
    },
}

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s %(threadName)s - %(funcName)s: %(message)s',
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)
logging.getLogger('requests').setLevel(logging.WARNING)


threads = []
stop_event = Event()

ENV = Environment(env_vars).validate()

out_queue = Queue(maxsize=100000)
m_timer = MonotonicGenerator(offset=ENV['CF_LOGS_START'], stop_event=stop_event, logger=logger)
threads.append(m_timer)
m_timer.start()

# r = Receiver(out_queue, stop_event=stop_event, adapter=NullStorage, logger=logger)
r = Receiver(
    out_queue,
    stop_event=stop_event,
    adapter=LogstashStorage,
    adapter_kwargs={"host":ENV['LOGSTASH_HOST'], "port": ENV['LOGSTASH_PORT']},
    num_workers=10,
    logger=logger)
threads.append(r)
r.start()

p = CloudFlareProducer(ENV['CF_ZONE_ID'], time_interval_q=m_timer.queue, out_q=out_queue, stop_event=stop_event, num_workers=4, logger=logger)
threads.append(p)
p.start()

watcher = Watcher(threads=threads, event=stop_event, logger=logger)
watcher.start()
try:
    watcher.join()
except KeyboardInterrupt:
    watcher.stop()
sys.exit(watcher.exit_code if watcher.exit_code is not None else 2)
