# -*- coding: utf-8 -*-
from app.watcher import Watcher
from app.environment import Environment
from app.storage import LogstashStorage
from app.monotonic import MonotonicGenerator
from app.receiver import Receiver
from app.producer.cloudflare import CloudFlareProducer
from app.producer.microsoft_atp import MicrosoftATPProducer
from queue import Queue
from threading import Event
import argparse
import logging
import sys

LOG_LEVELS = {
    "CRITICAL": logging.CRITICAL,
    "ERROR": logging.ERROR,
    "WARNING": logging.WARN,
    "INFO": logging.INFO,
    "DEBUG": logging.DEBUG,
    "NOTSET": logging.NOTSET,
}

env_vars = {
    "LOGS_START": {
        "required": True,
        "description": "The starting position of the logs. Must be no more than 7 days from now.",
        "default": "0",
        "type": float,
    },
    "LOGSTASH_HOST": {
        "required": True,
        "description": "Logstash host",
        "default": "logstash",
    },
    "LOGSTASH_PORT": {
        "required": True,
        "description": "Logstash port",
        "default": "5959",
        "type": int,
    },
    "LOG_LEVEL": {
        "required": True,
        "description": "Log level",
        "default": "INFO",
        "type": lambda x: LOG_LEVELS[x],
    },
}

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s %(threadName)s - %(funcName)s: %(message)s',
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)
logging.getLogger('requests').setLevel(logging.WARNING)

parser = argparse.ArgumentParser()
parser.add_argument('--producer', choices=['cloudflare', 'microsoft-atp'], default='cloudflare')
args = parser.parse_args()

threads = []
stop_event = Event()

ENV = Environment(env_vars).validate()

out_queue = Queue(maxsize=100000)
m_timer = MonotonicGenerator(offset=ENV['LOGS_START'], stop_event=stop_event, logger=logger)
threads.append(m_timer)
m_timer.start()

if args.producer == "cloudflare":
    producer_env = {
        "CF_API_EMAIL": {
            "required": True,
            "description": "CloudFlare Account email",
        },
        "CF_API_KEY": {
            "required": True,
            "description": "CloudFlare Account API key",
        },
        "CF_ZONE_ID": {
            "required": True,
            "description": "CloudFlare Zone ID",
        }
    }
    PRODUCER_ENV = Environment(producer_env).validate()
    p = CloudFlareProducer(PRODUCER_ENV['CF_ZONE_ID'], time_interval_q=m_timer.queue, out_q=out_queue,
                           stop_event=stop_event, num_workers=4, logger=logger)

if args.producer == "microsoft-atp":
    producer_env = {
        "AZURE_TENANT_ID": {
            "required": True,
            "description": "Azure tenant id",
        },
        "AZURE_CLIENT_ID": {
            "required": True,
            "description": "The Application ID assigned to your app when you registered it with Azure AD. You can find this in the Azure Portal. Click Azure Active Directory in the services sidebar, click App registrations, and choose the application.",
        },
        "AZURE_CLIENT_SECRET": {
            "required": True,
            "description": "The application secret that you created in the Azure Portal for your app under Keys. It cannot be used in a native app (public client), because client_secrets cannot be reliably stored on devices. It is required for web apps and web APIs (all confidential clients), which have the ability to store the client_secret securely on the server side. The client_secret should be URL-encoded before being sent.",
        }
    }
    PRODUCER_ENV = Environment(producer_env).validate()
    p = MicrosoftATPProducer(time_interval_q=m_timer.queue, out_q=out_queue, stop_event=stop_event, num_workers=4, logger=logger)

threads.append(p)
p.start()

# r = Receiver(out_queue, stop_event=stop_event, adapter=NullStorage, logger=logger)
r = Receiver(
    out_queue,
    stop_event=stop_event,
    adapter=LogstashStorage,
    adapter_kwargs={"host":ENV['LOGSTASH_HOST'], "port": ENV['LOGSTASH_PORT']},
    num_workers=10,
    logger=logger)
threads.append(r)
r.start()

watcher = Watcher(threads=threads, event=stop_event, logger=logger)
watcher.start()
try:
    watcher.join()
except KeyboardInterrupt:
    watcher.stop()
sys.exit(watcher.exit_code if watcher.exit_code is not None else 2)
