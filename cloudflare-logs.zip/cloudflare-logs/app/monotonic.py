from queue import Queue
from threading import Thread, Event
import datetime
import logging
import time
import pytz
import pickle
import os


class State(object):
    def __init__(self, initial_time, path="/state", logger=None):
        self._path = os.path.join(path, 'state.pickle')
        self._logger = logger or logging
        try:
            res = self.get()
            self._logger.debug("Loaded state: %s" % res)
        except Exception:
            self.set(initial_time)
            self._logger.debug("Started with initial state: %s" % initial_time)

    def get(self):
        with open(self._path, 'rb') as f:
            return pickle.load(f)

    def set(self, val):
        with open(self._path, 'wb') as f:
            pickle.dump(val, f)


class TimeInterval(object):
    def __init__(self, start, end):
        self._start = start
        self._end = end

    def __repr__(self):
        return "<Interval(start=%s,end=%s)>" % (self.start_rfc3339, self.end_rfc3339)

    @property
    def start_rfc3339(self):
        return self._start.strftime("%Y-%m-%dT%H:%M:%SZ")

    @property
    def end_rfc3339(self):
        return self._end.strftime("%Y-%m-%dT%H:%M:%SZ")

    @property
    def start_stamp(self):
        return "%s" % int(datetime.datetime.timestamp(self._start))

    @property
    def end_stamp(self):
        return "%s" % int(datetime.datetime.timestamp(self._end))


class MonotonicGenerator(Thread):
    def __init__(self, stop_event:Event, offset:float=None, logger=None):
        Thread.__init__(self, name="MonotonicGenerator")
        self._queue = Queue()
        self._stop_event = stop_event
        self._logger = logger or logging
        self._is_running=True
        offset = offset or time.time()
        self._sate = State(initial_time=offset)

    @property
    def queue(self):
        return self._queue

    def run(self):
        self._logger.info("Starting")
        time_adjustment = 10
        dt = datetime.datetime.fromtimestamp(self._sate.get(), tz=pytz.UTC)
        dt_without_seconds = dt.replace(second=0, microsecond=0)
        while self._is_running:
            dt_now = datetime.datetime.fromtimestamp(time.time(), tz=pytz.UTC)
            if dt_without_seconds + datetime.timedelta(minutes=10+time_adjustment) < dt_now:
                end = dt_without_seconds + datetime.timedelta(minutes=10)
                self._queue.put(TimeInterval(start=dt_without_seconds, end=end))
                dt_without_seconds = end
                self._sate.set(end.timestamp())
                continue

            if dt_without_seconds + datetime.timedelta(minutes=1+time_adjustment) < dt_now:
                end = dt_without_seconds + datetime.timedelta(minutes=1)
                self._queue.put(TimeInterval(start=dt_without_seconds, end=end))
                dt_without_seconds = end
                self._sate.set(end.timestamp())
                continue

            time.sleep(10)

    def stop(self):
        self._logger.debug("Stopping %s" % self.name)
        self._is_running = False
