from .base import BaseStorageAdapter
from queue import Empty
__all__ = [
    "NullStorage"
]


class NullStorage(BaseStorageAdapter):
    def run(self):
        self._logger.debug("Starting")
        while self._is_running or self._queue.qsize() > 0:
            try:
                raw = self._queue.get(timeout=3)
            except Empty:
                continue

            print(raw)
            self._queue.task_done()
