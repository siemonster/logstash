from .base import BaseStorageAdapter
__all__ = [
    "NullStorage"
]


class NullStorage(BaseStorageAdapter):
    def run(self):
        self._logger.debug("Starting")
        while self._is_running or self._queue.qsize() > 0:
            raw = self._queue.get()
            print(raw)
            self._queue.task_done()
