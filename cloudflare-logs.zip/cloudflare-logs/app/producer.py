# -*- coding: utf-8 -*-
from queue import Queue
from threading import Thread, Event
from traceback import format_exc
import logging
import CloudFlare


class CloudFlareWorker(Thread):
    def __init__(self, zone_id, cf:CloudFlare, time_interval_q: Queue, out_q: Queue, stop_event:Event, circuit_breaker, circuit_breaker_timeout=60, logger=None, name=None):
        Thread.__init__(self, daemon=True, name=name)
        self._time_interval_q = time_interval_q
        self._out_q = out_q
        self._logger = logger or logging
        self._is_running=True
        self._zone_id = zone_id
        self._stop_event = stop_event
        self._circuit_breaker = circuit_breaker
        self._circuit_breaker_timeout = circuit_breaker_timeout
        self._cf = cf

    def run(self):
        self._logger.debug("Starting")
        while self._is_running:
            self._circuit_breaker.wait(timeout=self._circuit_breaker_timeout)
            self._circuit_breaker.set()

            t_interval = self._time_interval_q.get()
            self._logger.debug(t_interval)
            try:
                res = self._cf.zones.logs.received.get(
                    self._zone_id, params={'start': t_interval.start_stamp, 'end': t_interval.end_stamp})
                if isinstance(res, list):
                    for el in res:
                        self._out_q.put({**el, 'zone_id':self._zone_id})
                elif isinstance(res, dict):
                    if res.get('code') == 429:
                        # back to queue
                        self._time_interval_q.put(t_interval)
                        self._logger.warning('Rate limits: exceeded')
                        self._circuit_breaker.clear()
                    if 400 <= res.get('code') <= 499:
                        self._logger.error(res)
                        self._stop_event.set()
                    if 500 <= res.get('code') <= 599:
                        # back to queue
                        self._time_interval_q.put(t_interval)
                        self._logger.warning(res)
                        self._circuit_breaker.clear()
                    if 600 <= res.get('code'):
                        self._logger.error(res)
                        self._stop_event.set()
                else:
                    self._logger.debug(res)
            except CloudFlare.exceptions.CloudFlareAPIError as e:
                # back to queue
                self._time_interval_q.put(t_interval)
                self._logger.warning("%s" % format_exc())
            except Exception as e:
                self._logger.error("%s" % format_exc())
                self._stop_event.set()
            self._time_interval_q.task_done()

    def stop(self):
        self._is_running = False


class CloudFlareProducer(Thread):
    def __init__(self, zone_id, time_interval_q: Queue, out_q: Queue, stop_event:Event, num_workers: int = 5, logger=None):
        Thread.__init__(self, name="CloudFlareProducer")
        self._zone_id = zone_id
        self._time_interval_q = time_interval_q
        self._out_q = out_q
        self._stop_event = stop_event
        self._num_workers = num_workers
        self._logger = logger or logging
        self._workers = []
        self._circuit_breaker=Event()
        self._circuit_breaker.set()
        self._cf = CloudFlare.CloudFlare(use_sessions=True)

    def run(self):
        self._logger.info("Starting (%s workers)" % self._num_workers)
        for w in range(self._num_workers):
            inst = CloudFlareWorker(
                self._zone_id, cf=self._cf, time_interval_q=self._time_interval_q, stop_event=self._stop_event,
                circuit_breaker=self._circuit_breaker, out_q=self._out_q,
                logger=self._logger, name="CloudFlareWorker-%s" % w)
            inst.start()
            self._workers.append(inst)
        for w in self._workers:
            w.join()

    def stop(self):
        for w in self._workers:
            self._logger.debug("Stopping %s" % w.name)
            w.stop()
